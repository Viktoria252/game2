<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="tree" tilewidth="64" tileheight="96" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="96" source="../../graphics/terrain/palm_large/tree_large.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="96" source="../../graphics/terrain/palm_small/tree_small.png"/>
 </tile>
</tileset>
