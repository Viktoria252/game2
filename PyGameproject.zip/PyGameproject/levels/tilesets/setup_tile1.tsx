<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="setup_tile1" tilewidth="82" tileheight="94" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="82" height="94" source="../../graphics/enemy/PigStop.png"/>
 </tile>
</tileset>
